public class NotaMedia {
    public static void main(String[] args) {
        float nota1 = 7.4f;
        float nota2 = 8.2f;
        float nota3 = 5.7f;
        float nota4 = 9.1f;

        float notaFinal = nota1+nota2+nota3+nota4;
        float mediaFinal = notaFinal / 4;

        System.out.println("A média final do aluno é de " + mediaFinal);
    }
}
