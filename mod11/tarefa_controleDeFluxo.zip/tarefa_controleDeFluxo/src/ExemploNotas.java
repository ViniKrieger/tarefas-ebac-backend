import java.util.Scanner;

public class ExemploNotas {

        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            double nota1, nota2, nota3, nota4;
            double media;

            System.out.println("Digite a primeira nota:");
            nota1 = input.nextDouble();

            System.out.println("Digite a segunda nota:");
            nota2 = input.nextDouble();

            System.out.println("Digite a terceira nota:");
            nota3 = input.nextDouble();

            System.out.println("Digite a quarta nota:");
            nota4 = input.nextDouble();

            media = (nota1 + nota2 + nota3 + nota4) / 4.0;

            System.out.println("A média do aluno é: " + media);

            if (media >= 7.0) {
                System.out.println("Aluno aprovado!");
            } else if (media >= 5.0) {
                System.out.println("Aluno em recuperação.");
            } else {
                System.out.println("Aluno reprovado.");
            }
        }
}