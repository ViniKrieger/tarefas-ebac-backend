import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

    public class OrganizadorGeneros {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            List<String> grupoMasculino = new ArrayList<>();
            List<String> grupoFeminino = new ArrayList<>();

            while (true) {
                System.out.print("Digite o nome da pessoa (ou 'sair' para encerrar): ");
                String nome = scanner.nextLine();

                if (nome.equalsIgnoreCase("sair")) {
                    break;
                }

                System.out.print("Digite o gênero (M para masculino, F para feminino): ");
                char genero = scanner.next().charAt(0);
                scanner.nextLine(); // Consumir a quebra de linha

                if (genero == 'M' || genero == 'm') {
                    grupoMasculino.add(nome);
                } else if (genero == 'F' || genero == 'f') {
                    grupoFeminino.add(nome);
                } else {
                    System.out.println("Gênero inválido. Por favor, digite M ou F.");
                }
            }

            System.out.println("\nGrupo Masculino:");
            for (String nome : grupoMasculino) {
                System.out.println(nome);
            }

            System.out.println("\nGrupo Feminino:");
            for (String nome : grupoFeminino) {
                System.out.println(nome);
            }

            scanner.close();
        }
    }

