
import java.util.Scanner;
import java.util.Arrays;

public class OrdenacaoNomes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite os nomes separados por vírgula: ");
        String entrada = scanner.nextLine();

        // Divide a entrada em nomes individuais
        String[] nomes = entrada.split(",");

        // Remove espaços em branco antes e depois de cada nome
        for (int i = 0; i < nomes.length; i++) {
            nomes[i] = nomes[i].trim();
        }

        // Ordena os nomes em ordem alfabética
        Arrays.sort(nomes);

        System.out.println("\nNomes em ordem alfabética:");
        for (String nome : nomes) {
            System.out.println(nome);
        }
    }
}

