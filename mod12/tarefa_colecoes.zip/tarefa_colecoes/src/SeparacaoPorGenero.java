import java.util.Scanner;
import java.util.ArrayList;

public class SeparacaoPorGenero {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite os nomes separados por vírgula e para identificar o sexo coloque M para masculino e F para feminino após o nome: ");
        String entrada = scanner.nextLine();

        // Divide a entrada em nomes individuais
        String[] nomes = entrada.split(",");

        // Remove espaços em branco antes e depois de cada nome
        for (int i = 0; i < nomes.length; i++) {
            nomes[i] = nomes[i].trim();
        }

        // Crie listas para armazenar nomes masculinos e femininos
        ArrayList<String> masculinos = new ArrayList<>();
        ArrayList<String> femininos = new ArrayList<>();

        // Separa os nomes em grupos de acordo com o último caractere
        for (String nome : nomes) {
            char ultimoCaractere = nome.charAt(nome.length() - 1);
            if (ultimoCaractere == 'M' || ultimoCaractere == 'm') {
                masculinos.add(nome);
            } else if (ultimoCaractere == 'F' || ultimoCaractere == 'f') {
                femininos.add(nome);
            }
        }

        // Imprime os grupos
        System.out.println("\nNomes Masculinos:");
        for (String nome : masculinos) {
            System.out.println(nome);
        }

        System.out.println("\nNomes Femininos:");
        for (String nome : femininos) {
            System.out.println(nome);
        }
    }
}
