import java.util.Scanner;

public class novaClasse {
    public static void main(String[]args){
        Scanner s = new Scanner(System.in);
        System.out.println("Digite sua idade: ");
        int idade = s.nextInt();
        Integer idade2 = idade;
        System.out.println("Você tem " + idade2 + " anos");
    }
}
