public class Caes {

    private String nome;
    private String raca;
    private int peso;
    private int idade;

    //Construtor da classe caes
    public Caes(String nome, String raca, int peso, int idade) {
        this.nome=nome;
        this.raca=raca;
        this.peso=peso;
        this.idade=idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    //Metodo para imrpimir detalhes do cachorro
    public void imprimirDetalhes() {
        System.out.println("Nome: "+ nome);
        System.out.println("Raça: "+ raca);
        System.out.println("Peso: "+ peso +" kg");
        System.out.println("Idade: "+ idade +" meses");
    }
}
