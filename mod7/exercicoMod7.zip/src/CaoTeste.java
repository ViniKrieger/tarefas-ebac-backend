public class CaoTeste {

    public static void main(String[] args) {

        //Criando objeto cachorro
        Caes cachorro1 = new Caes("Fred","Galgo",32,36);
        Caes cachorro2 = new Caes("Bob", "Golden Retriever", 22,10);

        //Impressão dos detalhes
        cachorro1.imprimirDetalhes();
        System.out.println();
        cachorro2.imprimirDetalhes();
    }
}
